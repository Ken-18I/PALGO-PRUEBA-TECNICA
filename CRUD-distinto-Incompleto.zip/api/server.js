const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const mysql = require('mysql');

const app = express();

// Configuración de CORS
app.use(cors());

// Configuración de Body-parser
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Configuración de MySQL
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Kenbatu123',
  database: 'courses_db'
});

// Conexión a MySQL
db.connect((err) => {
  if (err) {
    throw err;
  }
  console.log('Conexión exitosa a la base de datos MySQL.');
});

// Inicio del servidor
const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en el puerto ${PORT}.`);
});

// Obtener todos los cursos
app.get('/courses', (req, res) => {
    const sql = 'SELECT * FROM courses';
    db.query(sql, (err, result) => {
      if (err) {
        throw err;
      }
      res.send(result);
    });
  });
  
  // Obtener todos los estudiantes de un curso
  app.get('/students/:courseId', (req, res) => {
    const { courseId } = req.params;
    const sql = `SELECT * FROM students WHERE course_id = ${courseId}`;
    db.query(sql, (err, result) => {
      if (err) {
        throw err;
      }
      res.send(result);
    });
  });
  
  // Obtener todas las notas de un estudiante
  app.get('/grades/:studentId', (req, res) => {
    const { studentId } = req.params;
    const sql = `SELECT * FROM grades WHERE student_id = ${studentId}`;
    db.query(sql, (err, result) => {
      if (err) {
        throw err;
      }
      res.send(result);
    });
  });
  
  // Agregar una nueva nota para un estudiante
  app.post('/grades', (req, res) => {
    const { studentId, value } = req.body;
    const sql = `INSERT INTO grades (student_id, value) VALUES (${studentId}, ${value})`;
    db.query(sql, (err, result) => {
      if (err) {
        throw err;
      }
      res.send('Nota agregada correctamente.');
    });
  });
  