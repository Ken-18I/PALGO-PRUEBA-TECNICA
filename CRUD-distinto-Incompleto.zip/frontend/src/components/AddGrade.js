import React, { useState } from 'react';
import { useHistory, useParams } from 'react-router-dom';
import axios from 'axios';

function AddGrade() {
  const [name, setName] = useState('');
  const [grade, setGrade] = useState('');
  const history = useHistory();
  const { studentId } = useParams();

  const handleSubmit = (e) => {
    e.preventDefault();
    const data = {
      name,
      grade,
      studentId
    };
    axios.post('http://localhost:5000/grades', data)
      .then(res => {
        history.push(`/grades/${studentId}`);
      })
      .catch(err => {
        console.log(err);
      });
  }

  return (
    <div>
      <h1>Agregar nota</h1>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="name">Nombre:</label>
          <input type="text" id="name" name="name" value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div>
          <label htmlFor="grade">Nota:</label>
          <input type="number" id="grade" name="grade" value={grade} onChange={(e) => setGrade(e.target.value)} />
        </div>
        <button type="submit">Agregar nota</button>
      </form>
    </div>
  );
}

export default AddGrade;
