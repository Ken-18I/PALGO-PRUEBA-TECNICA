import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import axios from 'axios';

function GradesList() {
  const [grades, setGrades] = useState([]);
  const { studentId } = useParams();

  useEffect(() => {
    axios.get(`http://localhost:5000/grades?studentId=${studentId}`)
      .then(res => {
        setGrades(res.data);
      })
      .catch(err => {
        console.log(err);
      });
  }, [studentId]);

  const calculateAverage = () => {
    let sum = 0;
    for (let i = 0; i < grades.length; i++) {
      sum += grades[i].grade;
    }
    return sum / grades.length;
  }

  return (
    <div>
      <h1>Lista de notas del estudiante</h1>
      <ul>
        {grades.map(grade => (
          <li key={grade.id}>
            {grade.name}: {grade.grade}
          </li>
        ))}
      </ul>
      <p>Promedio: {calculateAverage()}</p>
      <Link to={`/add-grade/${studentId}`}>Agregar nota</Link>
      <br />
      <Link to={`/students/${grade.courseId}`}>Volver a la lista de estudiantes</Link>
    </div>
  );
}

export default GradesList;
