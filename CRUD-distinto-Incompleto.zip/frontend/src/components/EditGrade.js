import React, { useState, useEffect } from 'react';
import { useHistory, useParams } from 'react-router-dom';
import axios from 'axios';

function EditGrade() {
  const [name, setName] = useState('');
  const [grade, setGrade] = useState('');
  const history = useHistory();
  const { studentId, gradeId } = useParams();

  useEffect(() => {
    axios.get(`http://localhost:5000/grades/${gradeId}`)
      .then(res => {
        setName(res.data.name);
        setGrade(res.data.grade);
      })
      .catch(err => {
        console.log(err);
      });
  }, [gradeId]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const data = {
      name,
      grade,
      studentId
    };
    axios.put(`http://localhost:5000/grades/${gradeId}`, data)
      .then(res => {
        history.push(`/grades/${studentId}`);
      })
      .catch(err => {
        console.log(err);
      });
  }

  return (
    <div>
      <h1>Editar nota</h1>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="name">Nombre:</label>
          <input type="text" id="name" name="name" value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div>
          <label htmlFor="grade">Nota:</label>
          <input type="number" id="grade" name="grade" value={grade} onChange={(e) => setGrade(e.target.value)} />
        </div>
        <button type="submit">Editar nota</button>
      </form>
    </div>
  );
}

export default EditGrade;
