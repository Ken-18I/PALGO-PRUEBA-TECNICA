import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import axios from 'axios';

function StudentList() {
  const [students, setStudents] = useState([]);
  const { courseId } = useParams();

  useEffect(() => {
    axios.get(`http://localhost:5000/students?courseId=${courseId}`)
      .then(res => {
        setStudents(res.data);
      })
      .catch(err => {
        console.log(err);
      });
  }, [courseId]);

  return (
    <div>
      <h1>Lista de estudiantes del curso</h1>
      <ul>
        {students.map(student => (
          <li key={student.id}>
            <Link to={`/grades/${student.id}`}>{student.name}</Link>
          </li>
        ))}
      </ul>
      <Link to="/">Volver a la lista de cursos</Link>
    </div>
  );
}

export default StudentList;
