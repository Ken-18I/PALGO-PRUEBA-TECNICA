import logo from './logo.svg';
import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import './App.css';
import Header from './components/Header';
import CourseList from './components/CourseList';
import StudentList from './components/StudentList';
import GradesList from './components/GradesList';
import AddGrade from './components/AddGrade';
import EditGrade from './components/EditGrade';

function App() {
  return (
    <Router>
      <div className="container">
        <Switch>
          <Route exact path="/" component={CourseList} />
          <Route path="/students/:courseId" component={StudentList} />
          <Route path="/grades/:studentId" component={GradesList} />
          <Route path="/add-grade/:studentId" component={AddGrade} />
        </Switch>
      </div>
      <div className="App">
        <Header />
        <div className="container">
          <Switch>
            <Route exact path="/" component={StudentList} />
            <Route exact path="/grades/:studentId" component={GradesList} />
            <Route exact path="/grades/add/:studentId" component={AddGrade} />
            <Route exact path="/grades/edit/:studentId/:gradeId" component={EditGrade} />
          </Switch>
        </div>
      </div>
    </Router>

    
    
    
  );
}

export default App;